import User from "./User"
function App(){
  return(
    <>
  <h2>App Component</h2>
  <hr/>
  <User name="Amit" roll="10"/>
  <hr/>
  <User name="Sumit" roll="11"/>
  <hr/>
  <User name="Hari" roll="12"/>
    </>
  )
}
export default App 