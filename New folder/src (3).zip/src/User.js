function User(props){
    return(
        <>
        <h2>User-{props.name}</h2>
        <p>Roll No-{props.roll}</p>
        </>
    )
}

export default User 