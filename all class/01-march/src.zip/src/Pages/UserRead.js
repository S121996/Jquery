import React,{useState,useEffect} from 'react'
import axios from "axios"
import "./Allpages.css"
function UserRead() {
   let[val,setval] =useState()
   useEffect(()=>{
axios.get("http://localhost:3000/User").then((res)=>{
// console.log(res.data);
setval(res.data)
})

   },[])
  return (
<>
<div className='displaydata'>
  <table border="2px" className='mytable'>
<thead>
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>City</th>
    <th>Email</th>
    <th>Edit</th>
    <th>Delete</th>
  </tr>
</thead>
{val?<tbody>
  {val.map((item,index)=>{
return(
  <tr key={index}>
    <td>{item.id}</td>
    <td>{item.name}</td>
    <td>{item.age}</td>
    <td>{item.city}</td>
    <td>{item.email}</td>
    <td><i className='fa fa-edit'></i></td>
    <td><i className='fa fa-trash'></i></td>
  </tr>
)
  })}
</tbody>:null}


    
  </table>
</div>

</>
  )
}

export default UserRead