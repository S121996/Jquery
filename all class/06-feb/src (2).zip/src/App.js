
function App(props){
  // console.log(props.name);
  // console.log(props.age);
  return(
    <>
    <h2>User name-{props.name}</h2>
    <p>age-{props.age}</p>
    
    </>
  )
}
export default App 