import React from 'react'
import "./style.css"
function Header() {
  return (
   <>
   <div className='header'>
<p>MYCRUD Operations</p>
   </div>
   </>
  )
}

export default Header