
import User from './User'
function App() {
  return (
    <>
    <h3>App Component</h3>
    <hr/>
    <User> i am child </User>
    </>
  )
}

export default App