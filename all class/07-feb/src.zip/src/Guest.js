let Guest=(props)=>{
    return(
        <>
        <h2>Guest Component</h2>
        <p>Name={props.gdata}</p>
        </>
    )
}
export default Guest