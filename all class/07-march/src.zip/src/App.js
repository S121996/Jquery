import React from 'react'
import { Counter } from './features/counter/Counter'
import Data from './Data'
function App() {
  return (
    <>
    
    <h2>App component</h2>
    <hr/>
    <Counter/>
    <hr/>
    <Data/>
    </>
  )
}

export default App