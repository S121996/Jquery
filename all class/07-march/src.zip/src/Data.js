import React from 'react'
import { useSelector } from 'react-redux'
function Data() {
    const val = useSelector((state) => state.counter.value)
  return (
    <>
    <h2>Data component</h2>
    <h2>{val}</h2>
    </>
  )
}

export default Data