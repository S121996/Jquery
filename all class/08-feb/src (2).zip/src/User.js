

function User(props){
    return(
        <>
        <h2>User component</h2>
    <p>{props.children}</p>
        <hr/>
    
        </>
    )
}
export default User