import React, { Component } from 'react'

export default class App extends Component {
  state={
    name:"amit",
    age:20
  }
show=()=>{
  this.setState({name:"sumit",age:27})
  // this.setState({age:34})
}
  render() {
    return (
      <>
      <h2>App class component</h2>
      <h3>Name={this.state.name} age={this.state.age}</h3>
      <button onClick={this.show}>click</button>
      </>
    )
  }
}
