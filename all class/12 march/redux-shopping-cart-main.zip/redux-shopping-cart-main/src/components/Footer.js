import React from 'react';

const Footer = () => {
    return (
        <>
            <footer id="footer">
                <div className="container">
                    <p>
                        ductindia
                    </p>
                </div>
            </footer>
        </>
    );
};

export default Footer;