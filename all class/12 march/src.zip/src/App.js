import React,{useState} from 'react'

function App() {
 let[formdata,setformdata]=useState(
  {name:'',email:'',pass:''}
 )



let getdata=(e)=>{
// console.log(e.target);
let{name,value}=e.target
// console.log(name+" "+value);
setformdata({...formdata,[name]:value})
}
console.log(formdata);
  return (
   <>
   <form>
    Name:
    <input type="text" name="name" onChange={getdata}/>
    <br/><br/>
    Email:
    <input type="email" name="email" onChange={getdata}/>
    <br/><br/>
   Pass:
    <input type="text" name="pass" onChange={getdata}/>
   </form>
   
   </>
  )
}

export default App