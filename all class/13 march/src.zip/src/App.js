import React,{useState,useEffect} from 'react'

function App() {
    let[data,setdata]  =useState([])
    let[inputdata,setinputdata]=useState()

    let getdata=()=>{
      let result=localStorage.getItem('sdata')
      if(result){
        setdata(result)
      }
    }
    useEffect(()=>{
 getdata()
    },[])

let setData=()=>{
  localStorage.setItem('sdata',inputdata)
  setdata(inputdata)
}

let deleteData=()=>{
  localStorage.removeItem('sdata')
  getdata()
}
  return (
   <>
   <input type="text" name="name" placeholder='Type ur Value'
   onChange={(e)=>{setinputdata(e.target.value)}}/>
   <button onClick={setData}>Set Value</button>
   <button onClick={deleteData}>Clear value</button>
   <div>
    {data?<p>{data}</p>:<p>no data</p>}
   </div>
   </>
  )
}

export default App


