import React, { Component } from 'react'

export default class App extends Component {
  constructor(){
    super()
    console.log("App constructor called");
    this.state={
      name:"amit"
    }
  }
  static getDerivedStateFromProps(props,state)
{
console.log("app getDerivedStateFromProps called");
console.log(props,state);
return null 
}
componentDidMount()
{
  console.log("componentDidMount called");
}
  render() {
    console.log("app render");
    return (
      <>
      <h2>App class called</h2>
      
      
      
      </>
    )
  }
}
