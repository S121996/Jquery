import React from 'react'
import result from "./style.module.css"
import pic from "./pic2.jpg"
function App() {
  return (
    <>
 <h2 className={result.data}>App css Module</h2>
 <img src={pic} height="300px" width="30%" alt="..."/>
 <img src='image/data.jpg' alt=".."/>
    </>
  )
}

export default App
