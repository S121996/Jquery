import React from 'react'
import Guest from './Guest'
function User() {
  return (
    <>
    <h2>User component</h2>
    <hr/>
    <Guest/>
    </>
  )
}

export default User