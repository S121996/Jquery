import React from 'react'
import { Carousel } from '@trendyol-js/react-carousel';
import SliderItem from './SliderItem'
import SimpleImageSlider from "react-simple-image-slider";
function App() {

  const images = [
    { url: "image/data.jpg" },
    { url: "image/pic1.jpg" },
    { url: "image/pic2.jpg" },
    { url: "image/pic3.jpg" },
    { url: "image/pic4.jpg" },
    { url: "image/pic5.jpg" },
  ];

  return (
    <>
    <h2>App</h2>
    <Carousel show={5} slide={3} swiping={true}>
      <SliderItem name="amit" idata="image/data.jpg"/>
      <SliderItem name="sumit" idata="image/pic2.jpg"/>
      <SliderItem name="lalit" idata="image/pic1.jpg"/>
      <SliderItem name="hari" idata="image/pic3.jpg"/>
      <SliderItem name="rahul" idata="image/pic4.jpg"/>
      <SliderItem name="Arti" idata="image/pic5.jpg"/>
      <SliderItem name="Seema" idata="image/pic1.jpg"/>
      <SliderItem name="Reena" idata="image/pic4.jpg"/>
      <SliderItem name="Meena" idata="image/pic3.jpg"/>
      <SliderItem name="Deena" idata="image/data.jpg"/>
    </Carousel>
    <SimpleImageSlider
     width="100%"
     height={504}
     images={images}
     showBullets={true}
     showNavs={true}/>
    </>
  )
}

export default App