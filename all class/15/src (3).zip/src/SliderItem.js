import React from 'react'
import "./style.css"
function SliderItem(props) {
  return (
    <>
    <div className='item'>
        <img src={props.idata} height="100px" width="200px" alt=".."/>
        {props.name}
    </div>
    
    </>
  )
}

export default SliderItem