import React from 'react'

function Footer() {
  return (
   <>
   <div className='p-3 bg-dark text-white text-center fs-3'>My footer</div>
   </>
  )
}

export default Footer