import React from 'react'

function Header() {
  return (
    <>
    <div className='p-5 bg-info text-center fs-1'>
        This is Header
    </div>
    </>
  )
}

export default Header