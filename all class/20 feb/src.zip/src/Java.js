import React from 'react'

function Java() {
  return (
    <div>Java</div>
  )
}

export default Java