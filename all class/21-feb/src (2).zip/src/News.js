import React, { Component } from 'react'
import NewsItem from './NewsItem';
export default class News extends Component {
    constructor(){
        super()
        this.state={
            item:null
        }
    }
componentDidMount(){
   let result=fetch(`https://newsapi.org/v2/everything?q=${this.props.category}&language=hi&from=2024-02-15&to=2024-02-20&sortBy=popularity&apiKey=a53f9d592bcb4b328768abfedcdcbf8b`);
//    console.log(result);
     result.then((res)=>{
// console.log(res.json());
res.json().then((val)=>{
// console.log(val.articles);
this.setState({item:val.articles})
})
     })
}
  render() {
    console.log(this.state.item);
    return (
    <>
 {this.state.item?<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-2">
{this.state.item.map((pro,index)=>{
return(
<NewsItem
key={index}
title={pro.title}
dec={pro.description}
idata={pro.urlToImage}
url={pro.url}
/>
)
})}
 </div>:<p>no data</p>}
    
    </>
    )
  }
}
