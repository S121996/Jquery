import React, { Component } from 'react'
import pic from "./noimage.jpg"
export default class NewsItem extends Component {
  render() {
    let h={
        height:"550px"
    }
    return (
      <>
        <div class="col">
    <div class="card" style={h}>
      <img src={this.props.idata?this.props.idata:pic} class="card-img-top" alt="..."/>
      <div class="card-body">
        <h5 class="card-title">{this.props.title}</h5>
        <p class="card-text">{this.props.dec}</p>
        <a href={this.props.url}>More News</a>
      </div>
    </div>
  </div>
      
      
      </>
    )
  }
}
