import React,{useState,useEffect} from 'react'
import axios from 'axios'
import NewsItem from './NewsItem'
function News(props) {
      let[nitem,setnitem]=useState([])
    useEffect(()=>{
   let result=axios.get(`https://newsapi.org/v2/everything?q=${props.category}&language=hi&apiKey=a53f9d592bcb4b328768abfedcdcbf8b`)
//    console.log(result);
result.then((res)=>{
// console.log(res.data.articles);
setnitem(res.data.articles)
})
},[props.category])
// console.log(nitem);
  return (
    <>
  {nitem?<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-2">
    {nitem.map((item)=>{
return(
    <NewsItem
    title={item.title}
    dec={item.description}
    data={item.content}
    idata={item.urlToImage}
    url={item.url}
    />
)
    })}
  </div>:<p>No data</p>}
    </>
  )
}

export default News