import React from 'react'

function NewsItem(props) {
  console.log(props);
  let h={
    height:"600px"
  }
  return (
    <>
     <div class="col">
    <div class="card" style={h}>
      <img src={props.idata} class="card-img-top" alt="..."/>
      <div class="card-body">
        <h5 class="card-title">{props.title}</h5>
        <p class="card-text">{props.dec}</p>
        <p class="card-text">{props.data}</p>
        <a href={props.url}>More News</a>
      </div>
    </div>
  </div>
    </>
  )
}

export default NewsItem