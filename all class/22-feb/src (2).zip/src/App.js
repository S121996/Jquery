import React from 'react'
import User from './User'
import Admin from './Admin'
function App(props) {
let check=props.val
return(
  <>
  <h2>App Component</h2>
  {check && <User/>}
  </>
)
}

export default App