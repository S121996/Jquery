import React from 'react'

function User() {
  return (
   <>
   <h3>User Component</h3>
   
   </>
  )
}

export default User