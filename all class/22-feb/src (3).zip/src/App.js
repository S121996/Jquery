import React,{useState} from 'react'
import User from './User'
import Admin from './Admin'
function App() {
   let[check,setcheck] =useState(false)

let loginUser=()=>{
  setcheck(true)
}

let logoutUser=()=>{
  setcheck(false)
}
 let result;
 if(check){
  result=<User clickData={logoutUser}/>
 }
 else{
  result=<Admin clickData={loginUser}/>
 }
 return <div>
  {result}
 </div>
}

export default App