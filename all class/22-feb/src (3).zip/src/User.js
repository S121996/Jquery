import React from 'react'

function User(props) {
  return (
   <>
   <h3>User Component</h3>
   <button onClick={props.clickData}>logout</button>
   
   </>
  )
}

export default User