import React from 'react'

function Admin(props) {
  return (
    <>
    
    <h2>Admin component</h2>
    <button onClick={props.clickData}>login</button>
    <button>SignUp</button>
    </>
  )
}

export default Admin