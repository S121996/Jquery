import React,{useState} from 'react'
import User from './User'
import Admin from './Admin'
function App() {
   let[check,setcheck] =useState(false)

let loginUser=()=>{
  setcheck(true)
}

let logoutUser=()=>{
  setcheck(false)
}
return(
  <>
  {check?(<User clickData={logoutUser}/>):(<Admin clickData={loginUser}/>)}
  
  </>
)
}

export default App