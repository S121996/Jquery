import React,{useState} from 'react'
function App() {
  let[name,setname]=useState()
  let[email,setemail]=useState()
let show=(nameval)=>{
// console.log(nameval);
setname(nameval)
}
let show2=(emailval)=>{
  setemail(emailval)
}
let submitData=(e)=>{
  e.preventDefault()
  console.log("name="+name+"\nemail="+email);
}
  return (
    <>
    <form onSubmit={submitData}>
      Name:
      <input type="text" name="name" onChange={(e)=>{show(e.target.value)}}/>
      <br/><br/>
      Email:
      <input type="email" name="email" onChange={(e)=>{show2(e.target.value)}}/>
      <br/><br/>
      <input type="submit"/>
    </form>
    <div>
      
    </div>
    </>
  )
}

export default App