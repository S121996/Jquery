import React,{useState} from 'react'
function App() {
  let[name,setname]=useState()
  let[email,setemail]=useState()

let submitData=(e)=>{
  e.preventDefault()
  console.log("name="+name+"\nemail="+email);
}
  return (
    <>
    <form onSubmit={submitData}>
      Name:
      <input type="text" name="name" onChange={(e)=>{setname(e.target.value)}}/>
      <br/><br/>
      Email:
      <input type="email" name="email" onChange={(e)=>{setemail(e.target.value)}}/>
      <br/><br/>
      <input type="submit"/>
    </form>
    <div>
      
    </div>
    </>
  )
}

export default App