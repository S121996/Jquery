import React from 'react'

function Admin() {
  return (
    <>
    
    <h2>Admin component</h2>
    </>
  )
}

export default Admin