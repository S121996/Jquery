import React from 'react'
import User from './User'
import Admin from './Admin'
function App(props) {
let check=props.val
if(check){
  return <User/>
}
return<Admin/>
}

export default App