import React,{useState} from 'react'

function App() {
  let[no,setno]=useState(10)
  let inc=()=>{
    setno(no+1)
  }
  let dec=()=>{
    setno(no-1)
  }
  return (
    <>
    <button onClick={inc}>+</button>
    <span>{no}</span>
    <button onClick={dec}>-</button>
    
    </>
  )
}

export default App