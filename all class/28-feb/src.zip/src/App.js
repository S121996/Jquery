import React from 'react'
import UseCustomHook from './UseCustomHook'
function App() { 
     let data   =UseCustomHook()
     let data2  =UseCustomHook()
    
  return (
    <>
    <h2>{data.val}</h2>
    <button onClick={data.show}>click</button>
    <p>{data2.val}</p>
    <button onClick={data2.dec}>click</button>
    </>
  )
}

export default App