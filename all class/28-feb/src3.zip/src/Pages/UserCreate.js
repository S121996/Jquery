import React from 'react'

function UserCreate() {
  return (
    <div>UserCreate</div>
  )
}

export default UserCreate