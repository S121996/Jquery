import React from 'react'

function UserRead() {
  return (
    <div>UserRead</div>
  )
}

export default UserRead