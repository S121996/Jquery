// // function App(props){
// //   // console.log(props.name);
// //   // console.log(props.age);
// //   return(
// //     <>
// //     <h2>User name-{props.name}</h2>
// //     <p>age-{props.age}</p>
    
// //     </>
// //   )
// // }
// // export default App 

// // import React from 'react'
// // import User from './User'
// // function App() {
// //   let data="amit kumar"
// //   return (
// //     <>
// //     <h3>App Component</h3>
// //     <hr/>
// //     <User udata={data}/>
// //     </>
// //   )
// // }

// // export default App

// // import React, { Component } from 'react'

// // export default class App extends Component {
// //   state={
// //     name:"amit",
// //     age:25,
// //     sroll:this.props.roll
// //   }
// //   render() {
// //     return (
// //      <>
// //      <h2>App Component</h2>
// //      <h3>user name={this.state.name} user age={this.state.age}</h3>
// //      <p>roll no with props={this.props.roll}</p>
// //      <p>roll no with state={this.state.sroll}</p>
// //      </>
// //     )
// //   }
// // }



// // import React, { Component } from 'react'

// // export default class App extends Component {
// //   state={
// //    sroll:this.props.roll
// //   }
// // data=()=>{
// //   this.setState({sroll:this.state.sroll+1})
// // }
// //   render() {
// //     return (
// //       <>
// //       <h2>App class component</h2>
// //     <p>roll no with props={this.props.roll}</p>
// //     <p>roll no with state={this.state.sroll}</p>
// //     <button onClick={this.data}>click</button>
// //       </>
// //     )
// //   }
// // }


// // import React from 'react'
// // import User from './User'
// // export let contextData=React.createContext()
// // function App() {
// //   let data="amit kumar"
// //   return (
// //    <>
// //    <h2>App component</h2>
// //    <hr/>
// //    <contextData.Provider value={data}>
// //    <User/>
// //    </contextData.Provider>
  
// //    </>
// //   )
// // }

// // export default App

// // import React,{useState,useEffect} from 'react'

// // function App() {
// //   let[no,setno]=useState(1)
// //   let[data,setdata]=useState(100)

// //   let fun1=()=>{
// //     setno(no+1)
// //   }
// //   let fun2=()=>{
// //     setdata(data-1)
// //   }
// //   useEffect(()=>{
// //     console.log("useeffect called");
// //   },[no])
// //   return (
// //     <>
// //     <h2>number={no}</h2>
// //     <button onClick={fun1}>increment</button>
// //     <h2>value={data}</h2>
// //     <button onClick={fun2}>decrement</button>
    
// //     </>
// //   )
// // }

// // export default App


// // import React, { Component } from 'react'
// // import User from './User'
// // export default class App extends Component {
// //   constructor(){
// //     super()
// //     this.state={
// //       roll:50
// //     }
// //   }

// //   show=()=>{
// //    return this.setState({roll:this.state.roll+1})
// //   }
// //   render() {
// //     return (
// //       <>
// //       <User uroll={this.state.roll}/>
// //       <button onClick={this.show}>click</button>
// //       </>
// //     )
// //   }
// // }




// // import React, { Component } from 'react'
// // import User from './User'
// // export default class App extends Component {
// //   constructor(){
// //     super()
// //     this.state={
// //       roll:50
// //     }
// //   }

// //   show=()=>{
// //    return this.setState({roll:this.state.roll+1})
// //   }
// //   render() {
// //     return (
// //       <>
// //       <User uroll={this.state.roll}/>
// //       <button onClick={this.show}>click</button>
// //       </>
// //     )
// //   }
// // }

// // import React from 'react'
// // import User from './User'
// // export let contextData=React.createContext()
// // function App() {
// //   let data="amit kumar"
// //   return (
// //    <>
// //    <h2>App component</h2>
// //    <hr/>
// //    <contextData.Provider value={data}>
// //    <User/>
// //    </contextData.Provider>
  
// //    </>
// //   )
// // }

// // export default App

// // import React from 'react'

// // export default function App() {
// //   return (
// //     <div>App</div>
// //   )
// // }

// // import React from 'react'
// // import User from './User'
// // export let contextData=React.createContext()
// // function App() {
// //  let obj={
// //   name:"amit",
// //   age:20
// //  }
// //   return (
// //    <>
// //    <h2>App component</h2>
// //    <hr/>
// //    <contextData.Provider value={obj}>
// //    <User/>
// //    </contextData.Provider>
  
// //    </>
// //   )
// // }

// // export default App

// // import React from 'react'

// // import User from './User'
// // import {Provider} from "./ContextData"
// // function App() {
// // let age=20;
// //   return (
// //    <>
// //    <h2>App component</h2>
// //    <hr/>
// // <Provider value={age}>
// // <User/>
// // </Provider>
   
 
  
// //    </>
// //   )
// // }

// // export default App

// // import React from 'react'

// // function App() {
// //   let data={
// //     background:"orange",
// //     textAlign:"center",
// //     padding:"40px"
// //   }
// //   let data2={
// //     color:"red"
// //   }
// //   return (
// //  <>
 
// //  {/* <h2 style={data}>app component</h2> */}
// //  <h2 style={{...data,...data2,fontSize:"40px"}}>app component</h2>
// //  </>
// //   )
// // }

// // export default App

// // import React,{useState} from 'react'

// // function App() {
// //   let[check,setcheck] =useState(true)
// // let data1={
// //   background:"orange",
// //   color:"red"
// // }
// // let data2={
// //   background:"blue",
// //   color:"white"
// // }
// // let show=()=>{
// //   // setcheck(false)
// //   setcheck(check?false:true)
// // }
// //   return (
// //  <>
 

// //  <h2 style={check?data1:data2}>app component</h2>
// //  <button onClick={show}>click</button>
// //  </>
// //   )
// // }

// // export default App


// // import React from 'react'
// // import "./app.css"
// // function App() {
// //   return (
// //     <>
// //     {/* <h2 className='data txt'>hello users</h2> */}
// //     <h2 className={true?'data1':'data2'}>hello users</h2>
// //     </>
// //   )
// // }

// // export default App


// // import React from 'react'
// // import result from "./style.module.css"
// // import pic from "./pic2.jpg"
// // function App() {
// //   return (
// //     <>
// //  <h2 className={result.data}>App css Module</h2>
// //  <img src={pic} height="300px" width="30%" alt="..."/>
// //  <img src='image/data.jpg' alt=".."/>
// //     </>
// //   )
// // }

// // export default App
// // import React from 'react'
// // import {BrowserRouter,Routes,Route,Link} from "react-router-dom"

// // function App() {
// //   return (
// //     <>
// //     <BrowserRouter>
// //     <Link to="/">Home</Link>
// //     <br/> <br/>
// //     <Link to="/about">About</Link>
// //     <br/> <br/>
// //     <Link to="/news">news</Link>
// //     <br/> <br/>
// //     <Routes>
// //       <Route path='/' element={<h2>home page data</h2>}/>
// //       <Route path='/about' element={<h2>about page data</h2>}/>
// //       <Route path='/news' element={<h2>news page data</h2>}/>
// //       <Route path='*' element={<h2>not page data</h2>}/>
// //     </Routes>
    
// //     </BrowserRouter>
    
// //     </>
// //   )
// // }

// // export default App




// // import React from 'react'
// // import {BrowserRouter,Routes,Route,Link} from "react-router-dom"
// // function App() {
// //   return (
// //     <>
// //     <BrowserRouter>
// //     <Link to="/">Home</Link>
// //     <br/><br/>
// //     <Link to="/about">About</Link>
// //     <br/><br/>
// //     <Link to="/news">news</Link>
// //     <Routes>
// // <Route path='/' element={<h2>home page data</h2>}/>
// // <Route path='/about' element={<h2>about page data</h2>}/>
// // <Route path='/news' element={<h2>news page data</h2>}/>
// // <Route path='*' element={<h2>404 page not found</h2>}/>
// //     </Routes>
    
// //     </BrowserRouter>
// //     </>
// //   )
// // }

// // export default App


// // import React from 'react'
// // import {BrowserRouter,Routes,Route} from "react-router-dom"
// // import Home from './Home'
// // import About from './About'
// // import News from './News'
// // import Header from './Header'
// // import Menu from './Menu'
// // import Footer from './Footer'
// // function App() {
// //   return (
// //     <>
// //     <BrowserRouter>
// //     <Header/>
// //     <Menu/>
// //     <Routes>
// // <Route path='/' element={<Home/>}/>
// // <Route path='/about' element={<About/>}/>
// // <Route path='/news' element={<News/>}/>
// // <Route path='*' element={<h2>404 page not found</h2>}/>
// //     </Routes>
// //     <Footer/>
// //     </BrowserRouter>
// //     </>
// //   )
// // }
// // export default App

// import React from 'react'
// import {BrowserRouter,Routes,Route} from "react-router-dom"
// import Home from './Home'
// import About from './About'
// import News from './News'
// import Header from './Header'
// import Menu from './Menu'
// import Footer from './Footer'
// import Post from './Post'
// function App() {
//   return (
//     <>
//     <BrowserRouter>
//     <Header/>
//     <Menu/>
//     <Routes>
// <Route path='/' element={<Home/>}/>
// <Route path='/about' element={<About/>}/>
// <Route path='/news' element={<News/>}/>
// <Route path='/post' element={<Post/>}/>
// <Route path='/post/:category' element={<Post/>}/>
// <Route path='/post/:category/:id' element={<Post/>}/>
// <Route path='*' element={<h2>404 page not found</h2>}/>
//     </Routes>
//     <Footer/>
//     </BrowserRouter>
//     </>
//   )
// }
// export default App
// import React from 'react'
// import {BrowserRouter,Routes,Route} from "react-router-dom"
// import Home from './Home'
// import About from './About'
// import News from './News'
// import Header from './Header'
// import Menu from './Menu'
// import Footer from './Footer'
// import Post from './Post'
// function App() {
//   return (
//     <>
//     <BrowserRouter>
//     <Header/>
//     <Menu/>
//     <Routes>
// <Route path='/' element={<Home/>}/>
// <Route path='/about' element={<About/>}/>
// <Route path='/news' element={<News/>}/>
// <Route path='/post' element={<Post/>}/>
// <Route path='/post/:category' element={<Post/>}/>
// <Route path='/post/:category/:id' element={<Post/>}/>
// <Route path='*' element={<h2>404 page not found</h2>}/>
//     </Routes>
//     <Footer/>
//     </BrowserRouter>
//     </>
//   )
// }
// export default App

// import React,{useState} from 'react'
// import Data from './Data'
// const App = () => {
//       let[item,setitem] =useState(Data)
// let catfilter=(cat)=>{
//   let fdata=Data.filter((curele)=>{
// return cat===curele.category
//   })
//   // console.log(fdata);
//   setitem(fdata)
// }
// let subcatfilter=(cat,subcat)=>{
// let fsdata=Data.filter((val)=>{
// return cat===val.category && subcat===val.subcat
// })
// // console.log(fsdata);
// setitem(fsdata)
// }
//   return (
//    <>
//  <div className='container-fluid'>
//   <div className='row'>
//     <div className='left col-sm-12 col-md-4 col-lg-4 col-xl-3 col-xxl-2 p-3 '>
//     <ul className="list-group text-center ">
//   <li className="list-group-item active">Category</li>
//   <li className="list-group-item"><button className='btn' onClick={()=>{catfilter('mobile')}}>Mobile</button></li>
//   <li className="list-group-item"><button className='btn' onClick={()=>{catfilter('shirt')}}>Shirt</button></li>
//   <li className="list-group-item"><button className='btn' onClick={()=>{catfilter('watch')}}>Watch</button></li>
//   <li className="list-group-item"><button className='btn' onClick={()=>{setitem(Data)}}>All</button></li>
// </ul>

// <ul class="list-group text-center mt-4">
//   <li class="list-group-item active">Sub-Category Mobile</li>
//   <li class="list-group-item"><button className='btn' onClick={()=>{subcatfilter('mobile','lg')}}>LG</button></li>
//   <li class="list-group-item"><button className='btn' onClick={()=>{subcatfilter('mobile','nokia')}}>Nokia</button></li>
//   <li class="list-group-item"><button className='btn' onClick={()=>{subcatfilter('mobile','samsung')}}>Samsung</button></li>
// </ul>
//     </div>
//     <div className='right col-sm-12 col-md-8 col-lg-8 col-xl-9 col-xxl-10 p-3 '>
//       {item?<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-2">
//         {item.map((pro,index)=>{
// return(
//   <div className="col" key={index}>
//   <div className="card">
//     <img src={pro.pimage} className="card-img-top" alt="..."/>
//     <div className="card-body">
//       <h5 className="card-title">{pro.pname}</h5>
//       <p className="card-text">Price=Rs.{pro.price}</p>
//       <p>Category={pro.category} and subcat={pro.subcat}</p>
//       <button className='btn btn-danger'>Add to cart</button>
//     </div>
//   </div>
// </div>
// )
//         })}
//       </div>:<p>no data</p>}
//     </div>
//   </div>
//  </div>
   
   
//    </>
//   )
// }

// export default App


// import React,{useReducer} from 'react'
// const reducer=(state,action)=>{
//  if(action.type==='inc'){
//   state=state+1
//  }
//  if(state>0 && action.type==='dec'){
//   state=state-1
//  }
//  return state
// }
// function App() {
//            let inistatevalue=10   
//      let[state,dispatch] =useReducer(reducer,inistatevalue)
//   return (
//     <>
//     <button onClick={()=>{dispatch({type:'inc'})}}>+</button>
//     <span>{state}</span>
//     <button onClick={()=>{dispatch({type:'dec'})}}>-</button>
    
//     </>
//   )
// }

// export default App

import React,{useState} from 'react'
import "./style.css"
function App() {
     let[inputdata,setinputdata] =useState('')
     let[user,setuser] =useState([])

     let adduser=()=>{
     if(!inputdata){
      alert("field empty")
     }
     else
     {
      const mydata={
        id:new Date().getTime().toString(),
        name:inputdata
      }
      setuser([...user,mydata])
     }
     }
     let deleteUser=(sno)=>{
// console.log(sno);
let fdata=user.filter((pro)=>{
return sno !==pro.id
})
setuser(fdata)
     }
  return (
   <>
   <div className='main'>
    <div className='data'>
    <input type="text" name="n" className='myinput' onChange={(e)=>{setinputdata(e.target.value)}} />
    <i className="fa-solid fa-plus btn btn-outline-danger" onClick={adduser}></i>
    </div>
    <div className='showuser'>
      {user.map((item,index)=>{
return(
 <div className='myspan' key={index}>
   <span>{item.name} </span><i className="icon fa-solid fa-x" onClick={()=>{deleteUser(item.id)}}></i>
  </div>
)
      })}
    </div>
   </div>
   
   
   </>
  )
}

export default App

// import React,{useReducer} from 'react'
// const reducer=(state,action)=>{
//  if(action.type==='inc'){
//   state=state+1
//  }
//  if(state>0 && action.type==='dec'){
//   state=state-1
//  }
//  return state
// }
// function App() {
//            let inistatevalue=10   
//      let[state,dispatch] =useReducer(reducer,inistatevalue)
//   return (
//     <>
//     <button onClick={()=>{dispatch({type:'inc'})}}>+</button>
//     <span>{state}</span>
//     <button onClick={()=>{dispatch({type:'dec'})}}>-</button>
    
//     </>
//   )
// }

// export default App