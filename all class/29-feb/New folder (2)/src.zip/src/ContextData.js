// import React from "react"
// let contextAPI=React.createContext()
// let Provider=contextAPI.Provider;
// let Consumer=contextAPI.Consumer;

// export {Provider,Consumer}