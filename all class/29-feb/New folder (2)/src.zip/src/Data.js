const Data=[
    {id:1,pname:"Smart Mobile",price:35000,category:"mobile",subcat:"lg",pimage:"image/m1.jpg"},
    {id:2,pname:"Smart Mobile",price:32000,category:"mobile",subcat:"samsung",pimage:"image/m2.jpg"},
    {id:3,pname:"Smart Mobile",price:31000,category:"mobile",subcat:"nokia",pimage:"image/m3.jpg"},
    {id:4,pname:"Smart Mobile",price:30000,category:"mobile",subcat:"lg",pimage:"image/m4.jpg"},
    {id:5,pname:"shirt",price:1500,category:"shirt",subcat:"man",pimage:"image/s1.jpg"},
    {id:6,pname:"shirt",price:1200,category:"shirt",subcat:"kids",pimage:"image/s2.jpg"},
    {id:7,pname:"shirt",price:1400,category:"shirt",subcat:"woman",pimage:"image/s3.jpg"},
    {id:8,pname:"shirt",price:1100,category:"shirt",subcat:"man",pimage:"image/s4.jpg"},
    {id:9,pname:"watch",price:3500,category:"watch",subcat:"manwatch",pimage:"image/w1.jpg"},
    {id:10,pname:"watch",price:3800,category:"watch",subcat:"kidswatch",pimage:"image/w2.jpg"},
    {id:11,pname:"watch",price:3100,category:"watch",subcat:"womanwatch",pimage:"image/w3.jpg"},
    ]
    export default Data