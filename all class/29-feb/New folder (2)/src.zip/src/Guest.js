// let Guest=(props)=>{
//     return(
//         <>
//         <h2>Guest Component</h2>
//         <p>Name={props.gdata}</p>
//         </>
//     )
// }
// export default Guest

// import React from 'react'
// import { contextData } from './App'
// function Guest() {
//   return (
//    <>
//    <h2>Guest Component</h2>
//    <contextData.Consumer>

// {kuchbhi=><h4>{kuchbhi}</h4>}


//    </contextData.Consumer>
//    </>
//   )
// }

// export default Guest

// import React from 'react'
// import { contextData}from './App'

// function Guest() {
//   return (
//    <>
//    <h2>Guest Component</h2>
//    <contextData.Consumer>
//     { kuchbhi=><h1>kuchbhi</h1>}
//    </contextData.Consumer>
//    </>
//   )
// }

// export default Guest

// import React from 'react'
// import { contextData } from './App'
// function Guest() {
//   return (
//    <>
//    <h2>Guest Component</h2>
//    <contextData.Consumer>

// {kuchbhi=><h4>name={kuchbhi.name} age={kuchbhi.age}</h4>}


//    </contextData.Consumer>
//    </>
//   )
// }

// export default Guest

// import React from 'react'
// import {Consumer} from "./ContextData"
// function Guest() {
//   return (
//    <>
//    <h2>Guest Component</h2>
// <Consumer>
//   {val=><h2>{val}</h2>}
// </Consumer>
//    </>
//   )
// }

// export default Guest