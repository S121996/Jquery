// import Guest from "./Guest"

// function User(props){
//     return(
//         <>
//         <h2>User component</h2>
//         <p>{props.udata}</p>
//         <hr/>
//         <Guest gdata={props.udata}/>
//         </>
//     )
// }
// export default User

// function User(props){
//     return(
//         <>
//         <h2>User component</h2>
//     <p>{props.children}</p>
//         <hr/>
    
//         </>
//     )
// }
// export default User

// function User(props){
//     return(
//         <>
//         <h2>User component</h2>
//     <p>{props.children}</p>
//         <hr/>
    
//         </>
//     )
// }
// export default User

// import React from 'react'
// import Guest from './Guest'
// function User() {
//   return (
//     <>
//     <h2>User component</h2>
//     <hr/>
//     <Guest/>
//     </>
//   )
// }

// export default User


// import React, { Component } from 'react'

// export default class User extends Component {
//     constructor(props){
//         super(props)
//         this.state={
//             sroll:this.props.uroll
//         }
//     }
//     static getDerivedStateFromProps(props,state)
// {
//     console.log("user getDerivedStateFromProps called");
//     if(props.uroll!==state.sroll){
//         return {sroll:props.uroll}
//     }
//     return null 

// }
// shouldComponentUpdate(nextprops,nextstate)
// {
//    if(this.state.sroll<58){
//     console.log("user shouldComponentUpdate");
//     console.log(nextprops,nextstate);
//     return true
//    }
//    console.log(nextprops,nextstate);
//    return false
// }


// getSnapshotBeforeUpdate(prevprops,prevstate)
// {
// console.log("user getSnapshotBeforeUpdate called");
// console.log(prevprops,prevstate);
// return 190
// }
// componentDidUpdate(prevprops,prevstate,snapsort)
// {
// console.log("user componentDidUpdate called");
// console.log(prevprops,prevstate,snapsort);
// }
//   render() {
//     console.log(" user render");
//     return (
//       <>
//       <h2>User component</h2>
//       <h3>{this.state.sroll}</h3>
//       </>
//     )
//   }
// }




// import React, { Component } from 'react'

// export default class User extends Component {
//     constructor(props){
//         super(props)
//         this.state={
//             sroll:this.props.uroll
//         }
//     }

//     static getDerivedStateFromProps(props,state){
//         console.log("getDerivedStateFromProps called");
//         if(props.uroll!==state.sroll){
//             return{sroll:props.uroll}
//         }
//         return null
//     }
//     shouldComponentUpdate(nextprops,nextstate)
//     {
//        if(this.state.sroll<58){
//         console.log("user shouldComponentUpdate");
//         console.log(nextprops,nextstate);
//         return true
//        }
//        console.log(nextprops,nextstate);
//        return false
//     }
    
    
//     getSnapshotBeforeUpdate(prevprops,prevstate)
//     {
//     console.log("user getSnapshotBeforeUpdate called");
//     console.log(prevprops,prevstate);
//     return 190
//     }
//     componentDidUpdate(prevprops,prevstate,snapsort)
//     {
//     console.log("user componentDidUpdate called");
//     console.log(prevprops,prevstate,snapsort);
//     }
//       render() {
//         console.log(" user render");
//         return (
//           <>
//           <h2>User component</h2>
//           <h3>{this.state.sroll}</h3>
//           </>
//         )
//       }
//     }
    
// import React from 'react'
// import Guest from './Guest'
// function User() {
//   return (
//     <>
//     <h2>User component</h2>
//     <hr/>
//     <Guest/>
//     </>
//   )
// }

// export default User

// import React from 'react'
// import Guest from './Guest'
// function User() {
//   return (
//     <>
//     <h2>User component</h2>
//     <hr/>
//     <Guest/>
//     </>
//   )
// }

// export default User