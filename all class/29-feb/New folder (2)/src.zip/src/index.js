// import ReactDOM from 'react-dom'
// import App from './App';
// ReactDOM.render(
// <>
// <App name="sumit" age="30"/>
// <hr/>
// <App name="amit" age="20"/>
// <hr/>
// <App name="hari" age="27"/>
// <hr/>
// <App name="rahul" age="22"/>
// <hr/>
// </>,document.getElementById("root"));

// import App from "./App";
// import ReactDOM from 'react-dom'

// ReactDOM.render(<App/>,document.getElementById("root"))


// import App from "./App";
// import ReactDOM from 'react-dom'

// ReactDOM.render(<App roll="100"/>,document.getElementById("root"))




// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));
// let n=100
// root.render(<App roll={n}/>);




// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);




// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);



// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);



// import ReactDOM from 'react-dom/client';
// import App from './App';
// import "bootstrap/dist/css/bootstrap.min.css"
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);


// import ReactDOM from 'react-dom/client';
// import App from './App';
// import "bootstrap/dist/css/bootstrap.min.css"
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);

// import ReactDOM from 'react-dom/client';
// import App from './App';
// import "bootstrap/dist/css/bootstrap.min.css"
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render(<App />);
// import React,{ StrictMode } from 'react';
// import ReactDOM from 'react-dom/client';
// import App from './App';
// import "bootstrap/dist/css/bootstrap.min.css"
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render( <StrictMode>  
// <App/>
// </StrictMode>);

// import React,{ StrictMode } from 'react';
// import ReactDOM from 'react-dom/client';
// import App from './App';
// import "bootstrap/dist/css/bootstrap.min.css"
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render( <StrictMode>  
// <App/>
// </StrictMode>);

import React,{ StrictMode } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import "bootstrap/dist/css/bootstrap.min.css"
const root = ReactDOM.createRoot(document.getElementById('root'));

root.render( <StrictMode>  
<App/>
</StrictMode>);


// import React,{ StrictMode } from 'react';
// import ReactDOM from 'react-dom/client';
// import App from './App';
// import "bootstrap/dist/css/bootstrap.min.css"
// const root = ReactDOM.createRoot(document.getElementById('root'));

// root.render( <StrictMode>  
// <App/>
// </StrictMode>);












