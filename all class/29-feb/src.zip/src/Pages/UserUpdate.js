import React from 'react'

function UserUpdate() {
  return (
    <div>UserUpdate</div>
  )
}

export default UserUpdate