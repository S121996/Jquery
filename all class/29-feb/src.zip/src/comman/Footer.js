import React from 'react'
import "./style.css"
function Footer() {
  return (
   <>
   <div className='fdata'>
    <div className='fleft' id='myfooter'>
    <i class="fa-brands fa-facebook"></i>
    <i class="fa-brands fa-youtube"></i>
    <i class="fa-brands fa-square-instagram"></i>
    <i class="fa-brands fa-square-whatsapp"></i>
    </div>
    <div className='fleft'>
      <ul>
        <li>Category</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
      </ul>
    </div>
    <div className='fleft'>
    <ul>
        <li>Category</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
      </ul>
    </div>
    <div className='fleft'>
    <ul>
        <li>Category</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
        <li>Read Data</li>
      </ul>
    </div>
   </div>
   <div className='footer'>
    copyright@2024 ducat india
   </div>
   </>
  )
}

export default Footer