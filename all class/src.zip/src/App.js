

let Guest=()=>{
  return(
    <h2>Hello Users</h2>
  )
}

export default Guest




/*
function User(){
  return(
    <h2>welcome to React Component</h2>
  )
}

export default User 
*/ 