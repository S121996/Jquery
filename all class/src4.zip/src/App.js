import React,{Component} from "react";


class User extends Component{
  render(){
    return (
      <>
        <h2>hello users</h2>
      <p>s fsf sf sd fsdfsd</p>
      <h1>dad asd sad as dsa d sad</h1>
      </>
    )
  }
}
export default User 