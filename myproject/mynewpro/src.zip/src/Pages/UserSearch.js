import React from 'react'
import "./Allpages.css"
function UserSearch() {
  return (
    <>
    <div className='outer'>
    
        <span className='inner'>
          <input type="search" name="search" placeholder='search data' className='myinput'/>
          <i className="myicon fa-brands fa-searchengin"></i>
        </span>
    
    </div>
    
    <div className='displaydata'>
  <table border="2px" className='mytable'>
<thead>
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>City</th>
    <th>Email</th>
  </tr>
</thead>
</table>
</div>
    </>
  )
}

export default UserSearch